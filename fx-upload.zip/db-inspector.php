<?php
/**
 * Database Inspector
 * Tool untuk melihat isi database SQLite (tokens dan sessions)
 * 
 * Cara pakai:
 * 1. Upload file ini ke fx.idnads.pro/
 * 2. Akses: https://fx.idnads.pro/db-inspector.php
 * 3. Setelah selesai, HAPUS file ini!
 */

// Basic authentication (ubah username/password!)
$valid_user = 'admin';
$valid_pass = 'change-this-password';

if (!isset($_SERVER['PHP_AUTH_USER']) || 
    $_SERVER['PHP_AUTH_USER'] !== $valid_user || 
    $_SERVER['PHP_AUTH_PW'] !== $valid_pass) {
    header('WWW-Authenticate: Basic realm="DB Inspector"');
    header('HTTP/1.0 401 Unauthorized');
    die('Access denied');
}

require_once __DIR__ . '/config.php';
$config = require __DIR__ . '/config.php';

$dbPath = $config['db_path'];

if (!file_exists($dbPath)) {
    die('Database file not found: ' . $dbPath);
}

$pdo = new PDO('sqlite:' . $dbPath);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$action = $_GET['action'] ?? 'view';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Inspector</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #4CAF50; color: white; }
        tr:hover { background: #f5f5f5; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
        .stat-card { background: #e3f2fd; padding: 20px; border-radius: 8px; }
        .stat-card h3 { margin: 0 0 10px 0; color: #1976d2; }
        .stat-card p { font-size: 32px; margin: 0; font-weight: bold; color: #0d47a1; }
        .button { display: inline-block; padding: 10px 20px; background: #f44336; color: white; text-decoration: none; border-radius: 4px; margin: 10px 5px; }
        .button:hover { background: #d32f2f; }
        .warning { background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 4px; margin: 20px 0; }
        .code { background: #f5f5f5; padding: 3px 6px; border-radius: 3px; font-family: monospace; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Database Inspector</h1>
        
        <div class="warning">
            <strong>⚠️ WARNING:</strong> File ini hanya untuk debugging. Hapus file ini setelah selesai!<br>
            File: <code class="code"><?= basename(__FILE__) ?></code>
        </div>

        <?php if ($action === 'cleanup'): ?>
            <?php
            $db = new TokenDB($config);
            $db->cleanup();
            echo '<div style="background: #d4edda; padding: 15px; border-radius: 4px; margin: 20px 0;">
                    ✓ Cleanup completed successfully!
                  </div>';
            ?>
        <?php endif; ?>

        <h2>📊 Statistics</h2>
        <div class="stats">
            <?php
            $totalTokens = $pdo->query("SELECT COUNT(*) FROM tokens")->fetchColumn();
            $usedTokens = $pdo->query("SELECT COUNT(*) FROM tokens WHERE used = 1")->fetchColumn();
            $activeSessions = $pdo->query("SELECT COUNT(*) FROM sessions")->fetchColumn();
            $dbSize = filesize($dbPath);
            ?>
            <div class="stat-card">
                <h3>Total Tokens</h3>
                <p><?= $totalTokens ?></p>
            </div>
            <div class="stat-card">
                <h3>Used Tokens</h3>
                <p><?= $usedTokens ?></p>
            </div>
            <div class="stat-card">
                <h3>Active Sessions</h3>
                <p><?= $activeSessions ?></p>
            </div>
            <div class="stat-card">
                <h3>Database Size</h3>
                <p><?= number_format($dbSize / 1024, 2) ?> KB</p>
            </div>
        </div>

        <a href="?action=cleanup" class="button" onclick="return confirm('Run cleanup now?')">🧹 Run Cleanup</a>

        <h2>📝 Recent Tokens (Last 20)</h2>
        <table>
            <tr>
                <th>Token (truncated)</th>
                <th>Used</th>
                <th>Session ID</th>
                <th>Created</th>
                <th>Used At</th>
                <th>IP</th>
            </tr>
            <?php
            $stmt = $pdo->query("SELECT * FROM tokens ORDER BY created_at DESC LIMIT 20");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
            ?>
            <tr>
                <td><?= substr($row['token'], 0, 20) ?>...</td>
                <td><?= $row['used'] ? '✓ Yes' : '✗ No' ?></td>
                <td><?= $row['session_id'] ? substr($row['session_id'], 0, 12) . '...' : '-' ?></td>
                <td><?= date('Y-m-d H:i:s', $row['created_at']) ?></td>
                <td><?= $row['used_at'] ? date('Y-m-d H:i:s', $row['used_at']) : '-' ?></td>
                <td><?= htmlspecialchars($row['ip_address']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <h2>🔐 Active Sessions (Last 20)</h2>
        <table>
            <tr>
                <th>Session ID</th>
                <th>Token</th>
                <th>Created</th>
                <th>Last Activity</th>
                <th>Age (minutes)</th>
                <th>IP</th>
            </tr>
            <?php
            $stmt = $pdo->query("SELECT * FROM sessions ORDER BY last_activity DESC LIMIT 20");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                $age = round((time() - $row['last_activity']) / 60);
            ?>
            <tr>
                <td><?= substr($row['session_id'], 0, 12) ?>...</td>
                <td><?= substr($row['token'], 0, 12) ?>...</td>
                <td><?= date('Y-m-d H:i:s', $row['created_at']) ?></td>
                <td><?= date('Y-m-d H:i:s', $row['last_activity']) ?></td>
                <td><?= $age ?> min</td>
                <td><?= htmlspecialchars($row['ip_address']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>

        <h2>📈 Activity by Hour (Last 24h)</h2>
        <table>
            <tr>
                <th>Hour</th>
                <th>Tokens Generated</th>
                <th>Tokens Used</th>
            </tr>
            <?php
            $stmt = $pdo->query("
                SELECT 
                    strftime('%Y-%m-%d %H:00', created_at, 'unixepoch', 'localtime') as hour,
                    COUNT(*) as total,
                    SUM(used) as used
                FROM tokens
                WHERE created_at > " . (time() - 86400) . "
                GROUP BY hour
                ORDER BY hour DESC
            ");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
            ?>
            <tr>
                <td><?= $row['hour'] ?></td>
                <td><?= $row['total'] ?></td>
                <td><?= $row['used'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>

<?php
// Include TokenDB class for cleanup function
if (!class_exists('TokenDB')) {
    require_once __DIR__ . '/db.php';
}
?>
