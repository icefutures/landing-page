<?php
/**
 * Configuration file for fx.idnads.pro
 * DO NOT COMMIT THIS FILE TO VERSION CONTROL
 */

return [
    // Shared secret between tradecenter and fx for token validation
    'shared_secret' => 'CHANGE-THIS-TO-RANDOM-SECRET-' . bin2hex(random_bytes(16)),
    
    // Database path (SQLite)
    'db_path' => __DIR__ . '/data/tokens.db',
    
    // Session configuration
    'session_lifetime' => 86400, // 24 hours in seconds
    'session_cookie_name' => 'fx_session',
    
    // Token configuration
    'token_expiry' => 300, // 5 minutes (token valid for 5 minutes after generation)
    
    // Paths
    'expired_page' => '/expired.html',
    
    // Environment
    'environment' => 'production', // 'production' or 'development'
];
