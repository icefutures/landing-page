<?php
/**
 * Configuration file for tradecenter.idnads.pro
 * DO NOT COMMIT THIS FILE TO VERSION CONTROL
 * IMPORTANT: shared_secret MUST match fx.idnads.pro config
 */

return [
    // Shared secret between tradecenter and fx (MUST match fx.idnads.pro config)
    'shared_secret' => 'CHANGE-THIS-TO-RANDOM-SECRET-' . bin2hex(random_bytes(16)),
    
    // Redirect target URL
    'redirect_url' => 'https://fx.idnads.pro/invest',
    
    // Environment
    'environment' => 'production', // 'production' or 'development'
];
